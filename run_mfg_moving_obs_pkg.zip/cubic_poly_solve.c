/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * cubic_poly_solve.c
 *
 * Code generation for function 'cubic_poly_solve'
 *
 */

/* Include files */
#include "cubic_poly_solve.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"
#include <math.h>

/* Function Declarations */
static double rt_atan2d_snf(double u0, double u1);

/* Function Definitions */
static double rt_atan2d_snf(double u0, double u1)
{
  double y;
  int b_u0;
  int b_u1;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = rtNaN;
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      b_u0 = 1;
    } else {
      b_u0 = -1;
    }

    if (u1 > 0.0) {
      b_u1 = 1;
    } else {
      b_u1 = -1;
    }

    y = atan2(b_u0, b_u1);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

double cubic_poly_solve(double b, double d)
{
  double solution;
  double p;
  double q;
  double discrim;
  double rc;
  double s;

  /* UNTITLED13 Summary of this function goes here */
  /* root_vec = roots([1, cubic_coff1, 0,cubic_coff2]); */
  /*        cc = max(root_vec(imag(root_vec) == 0)); */
  /*  cc=cubic_poly_solve(cubic_coff1,0,cubic_coff2);  */
  p = 0.0 - b * (b / 3.0);
  q = (d + 2.0 * (b / 3.0 * (b / 3.0) * (b / 3.0))) - b * 0.0;

  /* equals cos(2*M_PI/3); */
  /* equals sin(2*M_PI/3); */
  /* equals cos(4*M_PI/3)=real3rdRoot1; */
  /* equals sin(4*M_PI/3)=-im3rdRoot1;   */
  if (p == 0.0) {
    rc = q;
    if (q < 0.0) {
      rc = -1.0;
    } else if (q > 0.0) {
      rc = 1.0;
    } else {
      if (q == 0.0) {
        rc = 0.0;
      }
    }

    solution = -rc * exp(log(fabs(q)) / 3.0);
  } else {
    discrim = q / 2.0 * (q / 2.0) + p / 3.0 * (p / 3.0) * (p / 3.0);
    s = sqrt(fabs(discrim));
    if (discrim < 0.0) {
      rc = exp(log(s * s + q * q / 4.0) / 6.0);
      p = rt_atan2d_snf(s, -q / 2.0) / 3.0;
      discrim = rc * cos(p);
      p = rc * sin(p);
      solution = fmax(2.0 * discrim, fmax(2.0 * (discrim * -0.5 - p *
        0.86602540378), 2.0 * (discrim * -0.5 - p * -0.86602540378)));
    } else if (discrim > 0.0) {
      p = -q / 2.0;
      q = p + s;
      p -= s;
      rc = q;
      if (q < 0.0) {
        rc = -1.0;
      } else if (q > 0.0) {
        rc = 1.0;
      } else {
        if (q == 0.0) {
          rc = 0.0;
        }
      }

      discrim = p;
      if (p < 0.0) {
        discrim = -1.0;
      } else if (p > 0.0) {
        discrim = 1.0;
      } else {
        if (p == 0.0) {
          discrim = 0.0;
        }
      }

      solution = rc * exp(log(fabs(q)) / 3.0) + discrim * exp(log(fabs(p)) / 3.0);
    } else {
      solution = fmax(3.0 * q / p, -3.0 * q / (2.0 * p));
    }
  }

  solution -= b / 3.0;
  return solution;
}

/* End of code generation (cubic_poly_solve.c) */
