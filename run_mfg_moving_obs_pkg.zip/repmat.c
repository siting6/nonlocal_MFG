/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * repmat.c
 *
 * Code generation for function 'repmat'
 *
 */

/* Include files */
#include "repmat.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"
#include <string.h>

/* Function Definitions */
void repmat(const double a[4096], double b[131072])
{
  int jtilecol;
  int ibtile;
  int jcol;
  int iacol_tmp;
  int ibmat;
  for (jtilecol = 0; jtilecol < 32; jtilecol++) {
    ibtile = (jtilecol << 12) - 1;
    for (jcol = 0; jcol < 64; jcol++) {
      iacol_tmp = jcol << 6;
      ibmat = ibtile + iacol_tmp;
      memcpy(&b[ibmat + 1], &a[iacol_tmp], 64U * sizeof(double));
    }
  }
}

/* End of code generation (repmat.c) */
