/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * dct2_simple.h
 *
 * Code generation for function 'dct2_simple'
 *
 */

#ifndef DCT2_SIMPLE_H
#define DCT2_SIMPLE_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void dct2_simple(const double arg1[4096], creal_T b[4096]);

#endif

/* End of code generation (dct2_simple.h) */
