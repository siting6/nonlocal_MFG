/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * idct_simple.h
 *
 * Code generation for function 'idct_simple'
 *
 */

#ifndef IDCT_SIMPLE_H
#define IDCT_SIMPLE_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void idct_simple(const creal_T b[4096], creal_T a[4096]);

#endif

/* End of code generation (idct_simple.h) */
