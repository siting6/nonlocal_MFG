/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * flipud.h
 *
 * Code generation for function 'flipud'
 *
 */

#ifndef FLIPUD_H
#define FLIPUD_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void b_flipud(creal_T x[4032]);
extern void flipud(creal_T x[4096]);

#endif

/* End of code generation (flipud.h) */
