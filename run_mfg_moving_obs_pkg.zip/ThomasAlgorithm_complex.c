/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * ThomasAlgorithm_complex.c
 *
 * Code generation for function 'ThomasAlgorithm_complex'
 *
 */

/* Include files */
#include "ThomasAlgorithm_complex.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"
#include <math.h>
#include <string.h>

/* Function Definitions */
void ThomasAlgorithm_complex(const double b[32], const creal_T f[32], creal_T s
  [32])
{
  creal_T d[32];
  creal_T u[32];
  int i;
  double br;
  double bi;
  double ar;
  double ai;
  double re;
  double im;
  double brm;
  double sgnbr;

  /* -----solve 3-diagonal system-------- */
  memset(&d[0], 0, 32U * sizeof(creal_T));
  memset(&u[0], 0, 32U * sizeof(creal_T));
  memset(&s[0], 0, 32U * sizeof(creal_T));
  for (i = 0; i < 31; i++) {
    if (i + 1 == 1) {
      u[0].re = 1024.0 / b[0];
      u[0].im = 0.0;
    } else {
      br = b[i] - 1024.0 * u[i - 1].re;
      bi = 0.0 - 1024.0 * u[i - 1].im;
      if (bi == 0.0) {
        re = 1024.0 / br;
        im = 0.0;
      } else if (br == 0.0) {
        re = 0.0;
        im = -(1024.0 / bi);
      } else {
        brm = fabs(br);
        im = fabs(bi);
        if (brm > im) {
          brm = bi / br;
          im = br + brm * bi;
          re = (1024.0 + brm * 0.0) / im;
          im = (0.0 - brm * 1024.0) / im;
        } else if (im == brm) {
          if (br > 0.0) {
            sgnbr = 0.5;
          } else {
            sgnbr = -0.5;
          }

          if (bi > 0.0) {
            im = 0.5;
          } else {
            im = -0.5;
          }

          re = (1024.0 * sgnbr + 0.0 * im) / brm;
          im = (0.0 * sgnbr - 1024.0 * im) / brm;
        } else {
          brm = br / bi;
          im = bi + brm * br;
          re = brm * 1024.0 / im;
          im = (brm * 0.0 - 1024.0) / im;
        }
      }

      u[i].re = re;
      u[i].im = im;
    }
  }

  for (i = 0; i < 32; i++) {
    if (i + 1 == 1) {
      if (f[0].im == 0.0) {
        d[0].re = f[0].re / b[0];
        d[0].im = 0.0;
      } else if (f[0].re == 0.0) {
        d[0].re = 0.0;
        d[0].im = f[0].im / b[0];
      } else {
        d[0].re = f[0].re / b[0];
        d[0].im = f[0].im / b[0];
      }
    } else {
      ar = f[i].re - 1024.0 * d[i - 1].re;
      ai = f[i].im - 1024.0 * d[i - 1].im;
      br = b[i] - 1024.0 * u[i - 1].re;
      bi = 0.0 - 1024.0 * u[i - 1].im;
      if (bi == 0.0) {
        if (ai == 0.0) {
          re = ar / br;
          im = 0.0;
        } else if (ar == 0.0) {
          re = 0.0;
          im = ai / br;
        } else {
          re = ar / br;
          im = ai / br;
        }
      } else if (br == 0.0) {
        if (ar == 0.0) {
          re = ai / bi;
          im = 0.0;
        } else if (ai == 0.0) {
          re = 0.0;
          im = -(ar / bi);
        } else {
          re = ai / bi;
          im = -(ar / bi);
        }
      } else {
        brm = fabs(br);
        im = fabs(bi);
        if (brm > im) {
          brm = bi / br;
          im = br + brm * bi;
          re = (ar + brm * ai) / im;
          im = (ai - brm * ar) / im;
        } else if (im == brm) {
          if (br > 0.0) {
            sgnbr = 0.5;
          } else {
            sgnbr = -0.5;
          }

          if (bi > 0.0) {
            im = 0.5;
          } else {
            im = -0.5;
          }

          re = (ar * sgnbr + ai * im) / brm;
          im = (ai * sgnbr - ar * im) / brm;
        } else {
          brm = br / bi;
          im = bi + brm * br;
          re = (brm * ar + ai) / im;
          im = (brm * ai - ar) / im;
        }
      }

      d[i].re = re;
      d[i].im = im;
    }
  }

  s[31] = d[31];
  for (i = 0; i < 31; i++) {
    im = u[30 - i].re;
    brm = u[30 - i].im;
    sgnbr = s[31 - i].im;
    br = s[31 - i].re;
    s[30 - i].re = d[30 - i].re - (im * br - brm * sgnbr);
    s[30 - i].im = d[30 - i].im - (im * sgnbr + brm * br);
  }

  /*  %%%%%%%example using Thomas Algorithm */
  /*  A = [1 1 0; 0 1 1; 0 0 1]'; */
  /*  f= [1;2;3]; */
  /*  a = [1;1]; \lower */
  /*  b = [1;1;1]; */
  /*  c = [0;0]; %upper */
  /*  n = 3; */
  /*  s = ThomasAlgorithm(a,b,c,f,n); */
  /*  sol = trim(A,f); */
}

/* End of code generation (ThomasAlgorithm_complex.c) */
