/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * fft.h
 *
 * Code generation for function 'fft'
 *
 */

#ifndef FFT_H
#define FFT_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void b_r2br_r2dit_trig(const creal_T x[8192], const double costab[65],
  const double sintab[65], creal_T y[8192]);
extern void c_r2br_r2dit_trig(const creal_T x[8192], const double costab[65],
  const double sintab[65], creal_T y[8192]);
extern void r2br_r2dit_trig(const double x[4096], const double costab[33], const
  double sintab[33], creal_T y[4096]);

#endif

/* End of code generation (fft.h) */
