/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * run_mfg_moving_obs_terminate.h
 *
 * Code generation for function 'run_mfg_moving_obs_terminate'
 *
 */

#ifndef RUN_MFG_MOVING_OBS_TERMINATE_H
#define RUN_MFG_MOVING_OBS_TERMINATE_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void run_mfg_moving_obs_terminate(void);

#endif

/* End of code generation (run_mfg_moving_obs_terminate.h) */
