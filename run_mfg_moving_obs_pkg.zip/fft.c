/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * fft.c
 *
 * Code generation for function 'fft'
 *
 */

/* Include files */
#include "fft.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"
#include <string.h>

/* Function Declarations */
static void r2br_r2dit_trig_impl(const creal_T x[8192], int xoffInit, const
  double costab[65], const double sintab[65], creal_T y[128]);

/* Function Definitions */
static void r2br_r2dit_trig_impl(const creal_T x[8192], int xoffInit, const
  double costab[65], const double sintab[65], creal_T y[128])
{
  int ix;
  int ju;
  int iy;
  int i;
  boolean_T tst;
  double twid_re;
  double temp_re;
  double twid_im;
  int iheight;
  double temp_im;
  double re;
  double im;
  int istart;
  int temp_re_tmp;
  int j;
  int ihi;
  ix = xoffInit;
  ju = 0;
  iy = 0;
  for (i = 0; i < 127; i++) {
    y[iy] = x[ix];
    iy = 128;
    tst = true;
    while (tst) {
      iy >>= 1;
      ju ^= iy;
      tst = ((ju & iy) == 0);
    }

    iy = ju;
    ix++;
  }

  y[iy] = x[ix];
  for (i = 0; i <= 126; i += 2) {
    twid_re = y[i + 1].re;
    temp_re = twid_re;
    twid_im = y[i + 1].im;
    temp_im = twid_im;
    re = y[i].re;
    im = y[i].im;
    twid_re = y[i].re - twid_re;
    y[i + 1].re = twid_re;
    twid_im = y[i].im - twid_im;
    y[i + 1].im = twid_im;
    y[i].re = re + temp_re;
    y[i].im = im + temp_im;
  }

  iy = 2;
  ix = 4;
  ju = 32;
  iheight = 125;
  while (ju > 0) {
    for (i = 0; i < iheight; i += ix) {
      temp_re_tmp = i + iy;
      temp_re = y[temp_re_tmp].re;
      temp_im = y[temp_re_tmp].im;
      y[temp_re_tmp].re = y[i].re - y[temp_re_tmp].re;
      y[temp_re_tmp].im = y[i].im - y[temp_re_tmp].im;
      y[i].re += temp_re;
      y[i].im += temp_im;
    }

    istart = 1;
    for (j = ju; j < 64; j += ju) {
      twid_re = costab[j];
      twid_im = sintab[j];
      i = istart;
      ihi = istart + iheight;
      while (i < ihi) {
        temp_re_tmp = i + iy;
        temp_re = twid_re * y[temp_re_tmp].re - twid_im * y[temp_re_tmp].im;
        temp_im = twid_re * y[temp_re_tmp].im + twid_im * y[temp_re_tmp].re;
        y[temp_re_tmp].re = y[i].re - temp_re;
        y[temp_re_tmp].im = y[i].im - temp_im;
        y[i].re += temp_re;
        y[i].im += temp_im;
        i += ix;
      }

      istart++;
    }

    ju /= 2;
    iy = ix;
    ix += ix;
    iheight -= iy;
  }
}

void b_r2br_r2dit_trig(const creal_T x[8192], const double costab[65], const
  double sintab[65], creal_T y[8192])
{
  int k;
  creal_T rwork[128];
  int xoff_tmp;

#pragma omp parallel for \
 num_threads(omp_get_max_threads()) \
 private(rwork,xoff_tmp)

  for (k = 0; k < 64; k++) {
    xoff_tmp = k << 7;
    r2br_r2dit_trig_impl(x, xoff_tmp, costab, sintab, rwork);
    memcpy(&y[xoff_tmp], &rwork[0], 128U * sizeof(creal_T));
  }
}

void c_r2br_r2dit_trig(const creal_T x[8192], const double costab[65], const
  double sintab[65], creal_T y[8192])
{
  int k;
  int i;
  creal_T rwork[128];
  int xoff_tmp;

#pragma omp parallel for \
 num_threads(omp_get_max_threads()) \
 private(rwork,xoff_tmp)

  for (k = 0; k < 64; k++) {
    xoff_tmp = k << 7;
    r2br_r2dit_trig_impl(x, xoff_tmp, costab, sintab, rwork);
    memcpy(&y[xoff_tmp], &rwork[0], 128U * sizeof(creal_T));
  }

  for (i = 0; i < 8192; i++) {
    y[i].re *= 0.0078125;
    y[i].im *= 0.0078125;
  }
}

void r2br_r2dit_trig(const double x[4096], const double costab[33], const double
                     sintab[33], creal_T y[4096])
{
  int k;
  creal_T rwork[64];
  int xoff_tmp;
  int ix;
  int ju;
  int iy;
  int i;
  boolean_T tst;
  double twid_re;
  double temp_re;
  double twid_im;
  int iheight;
  double temp_im;
  double re;
  double im;
  int istart;
  int temp_re_tmp;
  int j;
  int ihi;

#pragma omp parallel for \
 num_threads(omp_get_max_threads()) \
 private(rwork,xoff_tmp,ix,ju,iy,i,tst,twid_re,temp_re,twid_im,temp_im,re,im,iheight,istart,temp_re_tmp,j,ihi)

  for (k = 0; k < 64; k++) {
    xoff_tmp = k << 6;
    ix = xoff_tmp;
    ju = 0;
    iy = 0;
    for (i = 0; i < 63; i++) {
      rwork[iy].re = x[ix];
      rwork[iy].im = 0.0;
      iy = 64;
      tst = true;
      while (tst) {
        iy >>= 1;
        ju ^= iy;
        tst = ((ju & iy) == 0);
      }

      iy = ju;
      ix++;
    }

    rwork[iy].re = x[ix];
    rwork[iy].im = 0.0;
    for (i = 0; i <= 62; i += 2) {
      twid_re = rwork[i + 1].re;
      temp_re = twid_re;
      twid_im = rwork[i + 1].im;
      temp_im = twid_im;
      re = rwork[i].re;
      im = rwork[i].im;
      twid_re = rwork[i].re - twid_re;
      rwork[i + 1].re = twid_re;
      twid_im = rwork[i].im - twid_im;
      rwork[i + 1].im = twid_im;
      rwork[i].re = re + temp_re;
      rwork[i].im = im + temp_im;
    }

    iy = 2;
    ix = 4;
    ju = 16;
    iheight = 61;
    while (ju > 0) {
      for (i = 0; i < iheight; i += ix) {
        temp_re_tmp = i + iy;
        temp_re = rwork[temp_re_tmp].re;
        temp_im = rwork[temp_re_tmp].im;
        rwork[temp_re_tmp].re = rwork[i].re - rwork[temp_re_tmp].re;
        rwork[temp_re_tmp].im = rwork[i].im - rwork[temp_re_tmp].im;
        rwork[i].re += temp_re;
        rwork[i].im += temp_im;
      }

      istart = 1;
      for (j = ju; j < 32; j += ju) {
        twid_re = costab[j];
        twid_im = sintab[j];
        i = istart;
        ihi = istart + iheight;
        while (i < ihi) {
          temp_re_tmp = i + iy;
          temp_re = twid_re * rwork[temp_re_tmp].re - twid_im *
            rwork[temp_re_tmp].im;
          temp_im = twid_re * rwork[temp_re_tmp].im + twid_im *
            rwork[temp_re_tmp].re;
          rwork[temp_re_tmp].re = rwork[i].re - temp_re;
          rwork[temp_re_tmp].im = rwork[i].im - temp_im;
          rwork[i].re += temp_re;
          rwork[i].im += temp_im;
          i += ix;
        }

        istart++;
      }

      ju /= 2;
      iy = ix;
      ix += ix;
      iheight -= iy;
    }

    memcpy(&y[xoff_tmp], &rwork[0], 64U * sizeof(creal_T));
  }
}

/* End of code generation (fft.c) */
