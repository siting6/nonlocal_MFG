/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * run_mfg_moving_obs_data.h
 *
 * Code generation for function 'run_mfg_moving_obs_data'
 *
 */

#ifndef RUN_MFG_MOVING_OBS_DATA_H
#define RUN_MFG_MOVING_OBS_DATA_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Variable Declarations */
extern unsigned int state[625];
extern omp_nest_lock_t emlrtNestLockGlobal;
extern const double dv[65];
extern boolean_T isInitialized_run_mfg_moving_obs;

#endif

/* End of code generation (run_mfg_moving_obs_data.h) */
