/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * run_mfg_moving_obs_types.h
 *
 * Code generation for function 'run_mfg_moving_obs_types'
 *
 */

#ifndef RUN_MFG_MOVING_OBS_TYPES_H
#define RUN_MFG_MOVING_OBS_TYPES_H

/* Include files */
#include "rtwtypes.h"
#endif

/* End of code generation (run_mfg_moving_obs_types.h) */
