/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * run_mfg_moving_obs_terminate.c
 *
 * Code generation for function 'run_mfg_moving_obs_terminate'
 *
 */

/* Include files */
#include "run_mfg_moving_obs_terminate.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"
#include "run_mfg_moving_obs_data.h"

/* Function Definitions */
void run_mfg_moving_obs_terminate(void)
{
  omp_destroy_nest_lock(&emlrtNestLockGlobal);
  isInitialized_run_mfg_moving_obs = false;
}

/* End of code generation (run_mfg_moving_obs_terminate.c) */
