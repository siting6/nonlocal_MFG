/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * cat.c
 *
 * Code generation for function 'cat'
 *
 */

/* Include files */
#include "cat.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"

/* Function Definitions */
void cat(const double varargin_1[4096], const double varargin_2[4096], const
         double varargin_3[4096], const double varargin_4[4096], const double
         varargin_5[4096], const double varargin_6[4096], const double
         varargin_7[4096], const double varargin_8[4096], const double
         varargin_9[4096], const double varargin_10[4096], double y[40960])
{
  int iy;
  int j;
  iy = -1;
  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_1[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_2[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_3[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_4[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_5[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_6[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_7[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_8[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_9[j];
  }

  for (j = 0; j < 4096; j++) {
    iy++;
    y[iy] = varargin_10[j];
  }
}

/* End of code generation (cat.c) */
