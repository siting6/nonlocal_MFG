/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * flipud.c
 *
 * Code generation for function 'flipud'
 *
 */

/* Include files */
#include "flipud.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"

/* Function Definitions */
void b_flipud(creal_T x[4032])
{
  int j;
  int i;
  int xtmp_re_tmp;
  double xtmp_re;
  double xtmp_im;
  int b_i;
  for (j = 0; j < 64; j++) {
    for (i = 0; i < 31; i++) {
      xtmp_re_tmp = i + 63 * j;
      xtmp_re = x[xtmp_re_tmp].re;
      xtmp_im = x[xtmp_re_tmp].im;
      b_i = (63 * j - i) + 62;
      x[xtmp_re_tmp] = x[b_i];
      x[b_i].re = xtmp_re;
      x[b_i].im = xtmp_im;
    }
  }
}

void flipud(creal_T x[4096])
{
  int j;
  int xtmp_re_tmp_tmp;
  int i;
  int xtmp_re_tmp;
  double xtmp_re;
  double xtmp_im;
  int b_i;
  for (j = 0; j < 64; j++) {
    xtmp_re_tmp_tmp = j << 6;
    for (i = 0; i < 32; i++) {
      xtmp_re_tmp = i + xtmp_re_tmp_tmp;
      xtmp_re = x[xtmp_re_tmp].re;
      xtmp_im = x[xtmp_re_tmp].im;
      b_i = (xtmp_re_tmp_tmp - i) + 63;
      x[xtmp_re_tmp] = x[b_i];
      x[b_i].re = xtmp_re;
      x[b_i].im = xtmp_im;
    }
  }
}

/* End of code generation (flipud.c) */
