/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * circshift.c
 *
 * Code generation for function 'circshift'
 *
 */

/* Include files */
#include "circshift.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"

/* Function Definitions */
void circshift(double a[131072])
{
  int i;
  int pageroot;
  int j;
  int i1;
  double unusedU0;
  int k;
  for (i = 0; i < 32; i++) {
    pageroot = i << 12;
    for (j = 0; j < 64; j++) {
      i1 = pageroot + j;
      unusedU0 = a[i1];
      for (k = 0; k < 63; k++) {
        a[i1 + (k << 6)] = a[i1 + ((k + 1) << 6)];
      }

      a[i1 + 4032] = unusedU0;
    }
  }
}

/* End of code generation (circshift.c) */
