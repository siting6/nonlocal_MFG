/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sum.c
 *
 * Code generation for function 'sum'
 *
 */

/* Include files */
#include "sum.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"

/* Function Definitions */
void sum(const double x[4096], double y[64])
{
  int i;
  int xpageoffset;
  double d;
  int k;
  for (i = 0; i < 64; i++) {
    xpageoffset = i << 6;
    d = x[xpageoffset];
    for (k = 0; k < 63; k++) {
      d += x[(xpageoffset + k) + 1];
    }

    y[i] = d;
  }
}

/* End of code generation (sum.c) */
