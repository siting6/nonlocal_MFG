/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * cat.h
 *
 * Code generation for function 'cat'
 *
 */

#ifndef CAT_H
#define CAT_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void cat(const double varargin_1[4096], const double varargin_2[4096],
                const double varargin_3[4096], const double varargin_4[4096],
                const double varargin_5[4096], const double varargin_6[4096],
                const double varargin_7[4096], const double varargin_8[4096],
                const double varargin_9[4096], const double varargin_10[4096],
                double y[40960]);

#endif

/* End of code generation (cat.h) */
