/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * solvePoisson_time_space_2d_neumann_simple_for_mex.c
 *
 * Code generation for function 'solvePoisson_time_space_2d_neumann_simple_for_mex'
 *
 */

/* Include files */
#include "solvePoisson_time_space_2d_neumann_simple_for_mex.h"
#include "ThomasAlgorithm_complex.h"
#include "dct2_simple.h"
#include "idct_simple.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs.h"

/* Function Definitions */
void c_solvePoisson_time_space_2d_ne(const double rho_m_vec[131072], const
  double fv[4096], double F_phi_updates[131072])
{
  int l;
  int i;
  static creal_T F_rho_m_vec[131072];
  int j;
  int fv_tmp;
  double thomas_b[32];
  creal_T b_F_rho_m_vec[32];
  creal_T s[32];
  static creal_T phi_fouir_part[131072];
  static creal_T dcv[4096];
  static creal_T dcv1[4096];

  /* UNTITLED Summary of this function goes here */
  /*    Detailed explanation goes here */
  /*  do fourier transform */
  for (l = 0; l < 32; l++) {
    /*       F_rho_m_vec(:,:,l) =  mirt_dctn(rho_m_vec(:,:,l)); */
    i = l << 12;
    dct2_simple(*(double (*)[4096])&rho_m_vec[i], *(creal_T (*)[4096])&
                F_rho_m_vec[i]);
  }

  /*  %for each fourier mode, solve the (c1-(cx 2pi xi).^2 )* I + ct nalba_t = */
  /*  %rhs */
  /*  phi_fouir_part = zeros(M1,M2,N); */
  /*  negative_onesa = -(1*1/ht/ht)*ones(N-1,1); */
  /*  negative_onesc =negative_onesa ; */
  /*  negative_onesc(1)=0; */
  /*  for i = 1: (M1) %j is the corresponding fourier mode */
  /*      for j = 1:M2 */
  /*          %prepare the RHS, including t=0 added to first term */
  /*          % sth? */
  /*  %         if i>1 || j>1 */
  /*              f =  squeeze(F_rho_m_vec(i,j,:)); */
  /*              cc =  (fv(i,j))+ 2/ht/ht; */
  /*              thomas_b = cc*ones(N,1);  %%?? */
  /*              thomas_b(1) =  thomas_b(1)-1/ht/ht +1/ht; */
  /*              thomas_n = N; */
  /*              s = ThomasAlgorithm(negative_onesa,thomas_b,negative_onesc,f,thomas_n); */
  /*              phi_fouir_part(i,j,:) = s; */
  /*  %         end */
  /*      end */
  /*  end */
  for (l = 0; l < 64; l++) {
    /* j is the corresponding fourier mode */
    for (j = 0; j < 64; j++) {
      /* prepare the RHS, including t=0 added to first term */
      /*  sth? */
      /*          if i>1 || j>1 */
      fv_tmp = l + (j << 6);

      /* ?? */
      /*              thomas_b(1) =  thomas_b(1)+1/ht/ht -1/ht; */
      /*              thomas_b(N) =  thomas_b(N)+1/ht/ht; */
      for (i = 0; i < 32; i++) {
        thomas_b[i] = fv[fv_tmp] - 2048.0;
        b_F_rho_m_vec[i] = F_rho_m_vec[fv_tmp + (i << 12)];
      }

      thomas_b[0] = (thomas_b[0] + 1024.0) - 1024.0;
      ThomasAlgorithm_complex(thomas_b, b_F_rho_m_vec, s);

      /*              s = ThomasAlgorithm(negative_onesa,thomas_b,negative_onesc,f,thomas_n); */
      for (i = 0; i < 32; i++) {
        phi_fouir_part[fv_tmp + (i << 12)] = s[i];
      }

      /*          end */
    }
  }

  for (l = 0; l < 32; l++) {
    /*       F_phi_updates(:,:,l) = mirt_idctn(phi_fouir_part(:,:,l));%??testshape */
    /* IDCT2 Compute 2-D inverse discrete cosine transform. */
    /*    B = IDCT2(A) returns the two-dimensional inverse discrete */
    /*    cosine transform of A. */
    /*  */
    /*    B = IDCT2(A,[M N]) or B = IDCT2(A,M,N) pads A with zeros (or */
    /*    truncates A) to create a matrix of size M-by-N before */
    /*    transforming.  */
    /*  */
    /*    For any A, IDCT2(DCT2(A)) equals A to within roundoff error. */
    /*  */
    /*    The discrete cosine transform is often used for image */
    /*    compression applications. */
    /*  */
    /*    Class Support */
    /*    ------------- */
    /*    The input matrix A can be of class double or of any */
    /*    numeric class. The output matrix B is of class double. */
    /*  */
    /*    See also DCT2, DCTMTX, FFT2, IFFT2. */
    /*    Copyright 1993-2003 The MathWorks, Inc.   */
    /*    $Revision: 5.17.4.1 $  $Date: 2003/01/26 05:55:39 $ */
    /*    References:  */
    /*    1) A. K. Jain, "Fundamentals of Digital Image */
    /*       Processing", pp. 150-153. */
    /*    2) Wallace, "The JPEG Still Picture Compression Standard", */
    /*       Communications of the ACM, April 1991. */
    /*  checknargin(1,3,nargin,mfilename); */
    /* allocate space */
    /*  Basic algorithm. */
    i = l << 12;
    idct_simple(*(creal_T (*)[4096])&phi_fouir_part[i], dcv);
    for (j = 0; j < 64; j++) {
      for (fv_tmp = 0; fv_tmp < 64; fv_tmp++) {
        dcv1[fv_tmp + (j << 6)] = dcv[j + (fv_tmp << 6)];
      }
    }

    idct_simple(dcv1, dcv);
    for (j = 0; j < 64; j++) {
      for (fv_tmp = 0; fv_tmp < 64; fv_tmp++) {
        F_phi_updates[(fv_tmp + (j << 6)) + i] = dcv[j + (fv_tmp << 6)].re;
      }
    }

    /* ??testshape */
  }
}

/* End of code generation (solvePoisson_time_space_2d_neumann_simple_for_mex.c) */
