/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * solvePoisson_time_space_2d_neumann_simple_for_mex.h
 *
 * Code generation for function 'solvePoisson_time_space_2d_neumann_simple_for_mex'
 *
 */

#ifndef SOLVEPOISSON_TIME_SPACE_2D_NEUMANN_SIMPLE_FOR_MEX_H
#define SOLVEPOISSON_TIME_SPACE_2D_NEUMANN_SIMPLE_FOR_MEX_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void c_solvePoisson_time_space_2d_ne(const double rho_m_vec[131072],
  const double fv[4096], double F_phi_updates[131072]);

#endif

/* End of code generation (solvePoisson_time_space_2d_neumann_simple_for_mex.h) */
