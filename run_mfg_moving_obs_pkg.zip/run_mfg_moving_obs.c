/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * run_mfg_moving_obs.c
 *
 * Code generation for function 'run_mfg_moving_obs'
 *
 */

/* Include files */
#include "run_mfg_moving_obs.h"
#include "cat.h"
#include "circshift.h"
#include "cubic_poly_solve.h"
#include "randn.h"
#include "repmat.h"
#include "rt_nonfinite.h"
#include "run_mfg_moving_obs_data.h"
#include "run_mfg_moving_obs_initialize.h"
#include "solvePoisson_time_space_2d_neumann_simple_for_mex.h"
#include "sum.h"
#include "tic.h"
#include "toc.h"
#include <math.h>
#include <string.h>

/* Function Declarations */
static double rt_powd_snf(double u0, double u1);

/* Function Definitions */
static double rt_powd_snf(double u0, double u1)
{
  double y;
  double d;
  double d1;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = rtNaN;
  } else {
    d = fabs(u0);
    d1 = fabs(u1);
    if (rtIsInf(u1)) {
      if (d == 1.0) {
        y = 1.0;
      } else if (d > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = rtNaN;
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

void run_mfg_moving_obs(const double para[3], double totalitr, double a[320],
  double m[131072], double u[131072], double w1[131072], double w2[131072],
  double w3[131072], double w4[131072], double rho0[4096])
{
  double kernel_sigma1;
  double kernel_sigma2;
  double kernel_mu;
  int i;
  double x1;
  int j;
  double c_x1;
  double c1_x1;
  static double f0[4096];
  double pp2_idx_3;
  double x2;
  int i1;
  static double f1[4096];
  static double f2[4096];
  static double f11[4096];
  static double f22[4096];
  static double f12[4096];
  double f3_1[4096];
  double f3_2[4096];
  double f3_12[4096];
  double f3_21[4096];
  static double f[40960];
  double pp2_idx_2;
  double temp_m;
  double x[64];
  int k;
  int b_i;
  int pageroot;
  static short obs[131072];
  int itr;
  static double u_bar[131072];
  double a_bar[320];
  static double b_a[135168];
  static double w1_pada[135168];
  int f12_tmp;
  static double c_a[135168];
  static double w2_pada[135168];
  static double d_a[135168];
  static double w3_pada[135168];
  static double e_a[135168];
  static double w4_pada[135168];
  static double matrix_m_w[131072];
  static double B_star2[131072];
  static double B_star3[131072];
  static double B_star4[131072];
  if (isInitialized_run_mfg_moving_obs == false) {
    run_mfg_moving_obs_initialize();
  }

  /* solve mfg with non-local interaction */
  /* kernel coefficient fixed! */
  /* para: kernel parameters */
  /* splitting method */
  /* non-local mean-field game */
  /* fourier technique */
  /* with G-prox */
  /*  clear */
  /* parameters for pdhg algorithm */
  /* for primal variable m,w */
  /* for dual variable u */
  /* for variable a */
  /*  1*M1^2*N*stepsize1*stepstesize2 */
  /* domain */
  /* mesh */
  kernel_sigma1 = para[0];
  kernel_sigma2 = para[1];
  kernel_mu = para[2];

  /*  basis functions */
  for (i = 0; i < 64; i++) {
    x1 = (((double)i + 1.0) - 1.0) * 0.03125 - 1.0;
    for (j = 0; j < 64; j++) {
      c1_x1 = (((double)j + 1.0) - 1.0) * 0.03125 - 1.0;
      f0[i + (j << 6)] = sqrt(kernel_mu) * exp(-0.5 * (x1 * x1 / (kernel_sigma1 *
        kernel_sigma1) + c1_x1 * c1_x1 / (kernel_sigma2 * kernel_sigma2)));
    }
  }

  for (i = 0; i < 64; i++) {
    x1 = (((double)i + 1.0) - 1.0) * 0.03125 - 1.0;
    for (j = 0; j < 64; j++) {
      x2 = (((double)j + 1.0) - 1.0) * 0.03125 - 1.0;
      c_x1 = sqrt(kernel_mu) * exp(-0.5 * (x1 * x1 / (kernel_sigma1 *
        kernel_sigma1) + x2 * x2 / (kernel_sigma2 * kernel_sigma2)));
      i1 = i + (j << 6);
      f1[i1] = c_x1 * x1 / kernel_sigma1;
      f2[i1] = c_x1 * x2 / kernel_sigma2;
    }
  }

  /* f21 = f11; */
  c_x1 = kernel_sigma1 * kernel_sigma1;
  c1_x1 = kernel_sigma2 * kernel_sigma2;
  pp2_idx_3 = sqrt(kernel_mu);
  for (i = 0; i < 64; i++) {
    x1 = (((double)i + 1.0) - 1.0) * 0.03125 - 1.0;
    for (j = 0; j < 64; j++) {
      x2 = (((double)j + 1.0) - 1.0) * 0.03125 - 1.0;
      pp2_idx_2 = x2 * x2 / c1_x1;
      temp_m = pp2_idx_3 * exp(-0.5 * (x1 * x1 / c_x1 + pp2_idx_2));
      i1 = i + (j << 6);
      f11[i1] = temp_m * x1 * x1 / (1.4142135623730951 * c_x1);
      f22[i1] = temp_m * x2 * x2 / (1.4142135623730951 * c1_x1);
      f12[i1] = pp2_idx_3 * exp(-0.5 * (x1 * x1 / c_x1 + pp2_idx_2)) * x2 * x1 /
        (kernel_sigma2 * kernel_sigma1);
    }
  }

  for (i = 0; i < 64; i++) {
    x1 = (((double)i + 1.0) - 1.0) * 0.03125 - 1.0;
    for (j = 0; j < 64; j++) {
      x2 = (((double)j + 1.0) - 1.0) * 0.03125 - 1.0;
      c_x1 = sqrt(kernel_mu) * exp(-0.5 * (x1 * x1 / (kernel_sigma1 *
        kernel_sigma1) + x2 * x2 / (kernel_sigma2 * kernel_sigma2)));
      i1 = i + (j << 6);
      f3_1[i1] = c_x1 * x1 * x1 * x1 / (2.4494897427831779 * rt_powd_snf
        (kernel_sigma1, 3.0));
      c_x1 *= x2;
      c1_x1 = c_x1 * x2;
      f3_2[i1] = c1_x1 * x2 / (2.4494897427831779 * rt_powd_snf(kernel_sigma2,
        3.0));
      f3_12[i1] = c1_x1 * x1 / (1.4142135623730951 * (kernel_sigma2 *
        kernel_sigma2) * kernel_sigma1);
      f3_21[i1] = c_x1 * x1 * x1 / (1.4142135623730951 * kernel_sigma2 *
        (kernel_sigma1 * kernel_sigma1));

      /*  f21(i,j) = f12(i,j);%sqrt(kernel_mu)*exp(-0.5*((x1)^2/(kernel_sigma1^2) + (x2)^2/(kernel_sigma2^2)))*x2*x1/(kernel_sigma2*kernel_sigma1); */
    }
  }

  cat(f0, f1, f2, f11, f22, f12, f3_1, f3_2, f3_12, f3_21, f);

  /*  f = permute(f,[3,1,2]); */
  /* number of 2d basis */
  /* diagonal enrites of K^{-1} */
  memset(&a[0], 0, 320U * sizeof(double));

  /* a_i(t) i =1..rr */
  /*  running cost matrix */
  /*  initial boundary conditions */
  for (i = 0; i < 64; i++) {
    x1 = (((double)i + 1.0) * 0.03125 - 0.03125) - 1.0;
    c1_x1 = x1 * x1;
    for (j = 0; j < 64; j++) {
      x2 = (((double)j + 1.0) * 0.03125 - 0.03125) - 1.0;
      c_x1 = (x2 - 0.9) * (x2 - 0.9);
      f0[i + (j << 6)] = 2.0 * exp(-5.0 * (c1_x1 + 0.05 * c_x1)) * (c_x1 - 1.0)
        + c1_x1;
    }
  }

  for (i = 0; i < 64; i++) {
    x1 = (((double)i + 1.0) * 0.03125 - 0.03125) - 1.0;
    for (j = 0; j < 64; j++) {
      x2 = (((double)j + 1.0) * 0.03125 - 0.03125) - 1.0;
      c_x1 = (x2 + 0.9) * (x2 + 0.9);
      f1[i + (j << 6)] = (((99.47183943243455 * exp(-0.5 * ((c_x1 + x1 * x1) /
        0.0016000000000000007)) + 99.47183943243455 * exp(-0.5 * ((c_x1 + (x1 -
        0.4) * (x1 - 0.4)) / 0.0016000000000000007))) + 99.47183943243455 * exp(
        -0.5 * ((c_x1 + (x1 - 0.8) * (x1 - 0.8)) / 0.0016000000000000007))) +
                          99.47183943243455 * exp(-0.5 * ((c_x1 + (x1 + 0.4) *
        (x1 + 0.4)) / 0.0016000000000000007))) + 99.47183943243455 * exp(-0.5 *
        ((c_x1 + (x1 + 0.8) * (x1 + 0.8)) / 0.0016000000000000007));
    }
  }

  sum(f1, x);
  c_x1 = x[0];
  for (k = 0; k < 63; k++) {
    c_x1 += x[k + 1];
  }

  for (b_i = 0; b_i < 4096; b_i++) {
    pp2_idx_2 = f1[b_i] / c_x1 / 0.03125 / 0.03125;
    f1[b_i] = pp2_idx_2;
    f2[b_i] = 0.0;
    rho0[b_i] = pp2_idx_2;
    f12[b_i] = 0.0 * pp2_idx_2;
  }

  repmat(f12, m);
  repmat(f0, u);
  randn(w1);

  /*  obstacle setup */
  /* half of it */
  /* half of */
  /* obstacle set up */
  /* cound be time dependent */
  for (b_i = 0; b_i < 131072; b_i++) {
    pp2_idx_2 = 0.0 * w1[b_i];
    w1[b_i] = pp2_idx_2;
    w2[b_i] = pp2_idx_2;
    w3[b_i] = pp2_idx_2;
    w4[b_i] = pp2_idx_2;
    obs[b_i] = 0;
  }

  for (pageroot = 0; pageroot < 32; pageroot++) {
    c_x1 = 0.5 - ((double)pageroot + 1.0) * 0.03125;
    c1_x1 = 0.5 - 1.5 * ((double)pageroot + 1.0) * 0.03125;
    for (i = 0; i < 64; i++) {
      x1 = (((double)i + 1.0) - 1.0) * 0.03125 - 1.0;
      pp2_idx_2 = fabs((x1 + c1_x1) + 0.2);
      for (j = 0; j < 64; j++) {
        x2 = (((double)j + 1.0) - 1.0) * 0.03125 - 1.0;
        if ((fabs(x1 - c_x1) <= 0.3) && (fabs(x2 - 0.4) <= 0.05)) {
          obs[(i + (j << 6)) + (pageroot << 12)] = 500;
        }

        if ((fabs(x1 - (c1_x1 + 0.1)) <= 0.3) && (fabs(x2 - 0.1) <= 0.05)) {
          obs[(i + (j << 6)) + (pageroot << 12)] = 500;
        }

        if ((pp2_idx_2 <= 0.3) && (fabs(x2 + 0.2) <= 0.05)) {
          obs[(i + (j << 6)) + (pageroot << 12)] = 500;
        }

        if ((pp2_idx_2 <= 0.3) && (fabs(x2 + 0.5) <= 0.05)) {
          obs[(i + (j << 6)) + (pageroot << 12)] = 500;
        }
      }
    }
  }

  /*  pdhg  */
  /* fourier coefficient for Spatial Laplacian */
  for (i = 0; i < 64; i++) {
    c1_x1 = 2.0 * sin(3.1415926535897931 * (((double)i + 1.0) - 1.0) / 2.0 /
                      64.0);
    for (j = 0; j < 64; j++) {
      c_x1 = 2.0 * sin(3.1415926535897931 * (((double)j + 1.0) - 1.0) / 2.0 /
                       64.0);
      f11[i + (j << 6)] = -1024.0 * (c1_x1 * c1_x1) - 1024.0 * (c_x1 * c_x1);
    }
  }

  /*  record_diffm = zeros(max_iteration,1); */
  /*  record_diffw1 = zeros(max_iteration,1); */
  /*  record_diffu = zeros(max_iteration,1); */
  tic();
  b_i = (int)totalitr;
  for (itr = 0; itr < b_i; itr++) {
    /*      if mod(itr,500) ==0 */
    /*          itr */
    /*  %         sum(sum(m))*hx*hx */
    /*  %          */
    /*                  sum(sum(m(:,:,16)))*hx*hx */
    /*  %                 max(max(max(m))) */
    /*                  residual_cache = calculate_residual_neumann(m0,m,w1,w2,w3,w4,ht,hx,M1,M2,N) */
    /*                  record_residual(itr) = residual_cache; */
    /*                  residual_cache2 = calculate_residual_neumann_uw_runcost(runcost,u,m,w1,w2,w3,w4,ht,hx,M1,M2,N) */
    /*                  record_residual2(itr) = residual_cache2; */
    /*                 residual_cache3 =   calculate_residual_neumann_hjb_runcost_obstacles(runcost,u,g,a,f,obs,ht,hx,M1,M2,N) */
    /*                 record_residual3(itr) = residual_cache3; */
    /*                  */
    /*                  sum(sum(m(:,:,N)))*hx*hx */
    /*      end */
    /*      record_int(itr) = sum(sum(m))*hx*hx; */
    /*  use -bar to save previous iteration values */
    memcpy(&u_bar[0], &u[0], 131072U * sizeof(double));

    /*      u_int_bar = u_int; */
    memcpy(&a_bar[0], &a[0], 320U * sizeof(double));
    memcpy(&f22[0], &f2[0], 4096U * sizeof(double));

    /* update a */
    /* calculate the integration */
    for (i1 = 0; i1 < 10; i1++) {
      for (pageroot = 0; pageroot < 32; pageroot++) {
        for (i = 0; i < 64; i++) {
          for (k = 0; k < 64; k++) {
            f12_tmp = k + (i << 6);
            f12[f12_tmp] = m[f12_tmp + (pageroot << 12)] * f[f12_tmp + (i1 << 12)];
          }
        }

        sum(f12, x);
        c_x1 = x[0];
        for (k = 0; k < 63; k++) {
          c_x1 += x[k + 1];
        }

        f12_tmp = i1 + 10 * pageroot;
        a[f12_tmp] = (a[f12_tmp] + 0.0001953125 * c_x1) / 1.2;
      }
    }

    for (i = 0; i < 4096; i++) {
      f2[i] -= 0.2 * (f1[i] - rho0[i]);
    }

    /* dual update */
    /* Y = circshift(A,K,dim) */
    for (k = 0; k < 32; k++) {
      for (j = 0; j < 64; j++) {
        i1 = 66 * j + 4224 * k;
        w1_pada[i1] = 0.0;
        f12_tmp = i1 + 65;
        w1_pada[f12_tmp] = 0.0;
        w2_pada[i1] = 0.0;
        w2_pada[f12_tmp] = 0.0;
        i1 = j + 4224 * k;
        w3_pada[i1] = 0.0;
        f12_tmp = i1 + 4160;
        w3_pada[f12_tmp] = 0.0;
        w4_pada[i1] = 0.0;
        w4_pada[f12_tmp] = 0.0;
        memcpy(&w1_pada[(k * 4224 + j * 66) + 1], &w1[k * 4096 + j * 64], 64U *
               sizeof(double));
        memcpy(&w2_pada[(k * 4224 + j * 66) + 1], &w2[k * 4096 + j * 64], 64U *
               sizeof(double));
        memcpy(&w3_pada[(k * 4224 + j * 64) + 64], &w3[k * 4096 + j * 64], 64U *
               sizeof(double));
        memcpy(&w4_pada[(k * 4224 + j * 64) + 64], &w4[k * 4096 + j * 64], 64U *
               sizeof(double));
      }
    }

    memcpy(&b_a[0], &w1_pada[0], 135168U * sizeof(double));
    for (i = 0; i < 2048; i++) {
      pageroot = i * 66;
      c_x1 = b_a[pageroot + 65];
      for (k = 64; k >= 0; k--) {
        f12_tmp = pageroot + k;
        b_a[f12_tmp + 1] = b_a[f12_tmp];
      }

      b_a[pageroot] = c_x1;
    }

    memcpy(&c_a[0], &w2_pada[0], 135168U * sizeof(double));
    for (i = 0; i < 2048; i++) {
      pageroot = i * 66;
      c_x1 = c_a[pageroot];
      for (k = 0; k < 65; k++) {
        f12_tmp = pageroot + k;
        c_a[f12_tmp] = c_a[f12_tmp + 1];
      }

      c_a[pageroot + 65] = c_x1;
    }

    memcpy(&d_a[0], &w3_pada[0], 135168U * sizeof(double));
    for (i = 0; i < 32; i++) {
      pageroot = i * 4224;
      for (j = 0; j < 64; j++) {
        i1 = pageroot + j;
        c_x1 = d_a[i1 + 4160];
        for (k = 64; k >= 0; k--) {
          d_a[i1 + ((k + 1) << 6)] = d_a[i1 + (k << 6)];
        }

        d_a[i1] = c_x1;
      }
    }

    memcpy(&e_a[0], &w4_pada[0], 135168U * sizeof(double));
    for (i = 0; i < 32; i++) {
      pageroot = i * 4224;
      for (j = 0; j < 64; j++) {
        i1 = pageroot + j;
        c_x1 = e_a[i1];
        for (k = 0; k < 65; k++) {
          e_a[i1 + (k << 6)] = e_a[i1 + ((k + 1) << 6)];
        }

        e_a[i1 + 4160] = c_x1;
      }
    }

    for (i = 0; i < 135168; i++) {
      w1_pada[i] -= b_a[i];
      c_a[i] -= w2_pada[i];
      w3_pada[i] -= d_a[i];
      e_a[i] -= w4_pada[i];
    }

    for (i = 0; i < 32; i++) {
      for (k = 0; k < 64; k++) {
        for (f12_tmp = 0; f12_tmp < 64; f12_tmp++) {
          j = ((f12_tmp + 66 * k) + 4224 * i) + 1;
          i1 = (f12_tmp + ((k + 1) << 6)) + 4224 * i;
          matrix_m_w[(f12_tmp + (k << 6)) + (i << 12)] = ((32.0 * w1_pada[j] +
            32.0 * c_a[j]) + 32.0 * w3_pada[i1]) + 32.0 * e_a[i1];
        }
      }
    }

    /*      matrix_m_w = 1/hx*(w1 - circshift(w1,1,1)) + 1/hx*( circshift(w2,-1,1) - w2) + 1/hx*(w3 - circshift(w3,1,2))+ 1/hx*( circshift(w4,-1,2) - w4) ; */
    for (pageroot = 0; pageroot < 31; pageroot++) {
      for (i = 0; i < 64; i++) {
        for (k = 0; k < 64; k++) {
          f12_tmp = k + (i << 6);
          j = f12_tmp + ((pageroot + 1) << 12);
          matrix_m_w[j] += (m[j] - m[f12_tmp + (pageroot << 12)]) / 0.03125;
        }
      }
    }

    for (i = 0; i < 64; i++) {
      for (k = 0; k < 64; k++) {
        j = k + (i << 6);
        matrix_m_w[j] += (m[j] - f1[j]) / 0.03125;
      }
    }

    /*      record_diffu(itr) = sum(sum(sum((u-u_bar).^2))); */
    /* using Gprox */
    /*       u_update = solvePoisson_time_space_2d_Neumann(M1,M2,N,matrix_m_w,ht,1,1,fLapalacian); */
    /*       u_update = solvePoisson_time_space_2d_neumann_test(M1,M2,N,matrix_m_w,ht,fLapalacian); */
    /*      u_update =  solvePoisson_time_space_2d_Periodic(M1,M2,N,matrix_m_w,ht,fLapalacian); */
    c_solvePoisson_time_space_2d_ne(matrix_m_w, f11, B_star2);

    /* L2 */
    /*      u = u -  stepsize2*matrix_m_w; */
    /* extra interpolation step */
    for (i = 0; i < 131072; i++) {
      pp2_idx_2 = u[i] + 0.5 * B_star2[i];
      u[i] = pp2_idx_2;
      u_bar[i] = 2.0 * pp2_idx_2 - u_bar[i];
    }

    for (i = 0; i < 320; i++) {
      a_bar[i] = 2.0 * a[i] - a_bar[i];
    }

    for (i = 0; i < 4096; i++) {
      f22[i] = 2.0 * f2[i] - f22[i];
    }

    /* primal update */
    /*      prem = m; */
    /*      prew1 = w1; */
    for (i = 0; i < 64; i++) {
      for (k = 0; k < 64; k++) {
        i1 = k + (i << 6);
        f1[i1] -= 0.2 * (32.0 * u_bar[i1] - f22[i1]);
      }
    }

    memcpy(&matrix_m_w[0], &u_bar[0], 131072U * sizeof(double));
    for (i = 0; i < 2048; i++) {
      pageroot = i << 6;
      c_x1 = matrix_m_w[pageroot];
      for (k = 0; k < 63; k++) {
        j = pageroot + k;
        matrix_m_w[j] = matrix_m_w[j + 1];
      }

      matrix_m_w[pageroot + 63] = c_x1;
    }

    for (i = 0; i < 131072; i++) {
      matrix_m_w[i] = -(matrix_m_w[i] - u_bar[i]) / 0.03125;
      B_star2[i] = u_bar[i];
    }

    for (i = 0; i < 2048; i++) {
      pageroot = i << 6;
      c_x1 = B_star2[pageroot + 63];
      for (k = 62; k >= 0; k--) {
        i1 = pageroot + k;
        B_star2[i1 + 1] = B_star2[i1];
      }

      B_star2[pageroot] = c_x1;
    }

    for (i = 0; i < 131072; i++) {
      B_star2[i] = -(u_bar[i] - B_star2[i]) / 0.03125;
      B_star3[i] = u_bar[i];
    }

    circshift(B_star3);
    for (i = 0; i < 131072; i++) {
      B_star3[i] = -(B_star3[i] - u_bar[i]) / 0.03125;
      B_star4[i] = u_bar[i];
    }

    for (i = 0; i < 32; i++) {
      pageroot = i << 12;
      for (j = 0; j < 64; j++) {
        i1 = pageroot + j;
        c_x1 = B_star4[i1 + 4032];
        for (k = 62; k >= 0; k--) {
          B_star4[i1 + ((k + 1) << 6)] = B_star4[i1 + (k << 6)];
        }

        B_star4[i1] = c_x1;
      }
    }

    for (i = 0; i < 131072; i++) {
      B_star4[i] = -(u_bar[i] - B_star4[i]) / 0.03125;
    }

    for (i = 0; i < 32; i++) {
      pageroot = i << 12;
      for (k = 0; k < 64; k++) {
        f12_tmp = (k << 6) + pageroot;
        j = f12_tmp + 63;
        matrix_m_w[j] *= 0.0;
        B_star2[f12_tmp] *= 0.0;
        f12_tmp = k + pageroot;
        i1 = f12_tmp + 4032;
        B_star3[i1] *= 0.0;
        B_star4[f12_tmp] *= 0.0;
      }
    }

    for (pageroot = 0; pageroot < 32; pageroot++) {
      for (i = 0; i < 64; i++) {
        for (j = 0; j < 64; j++) {
          if (pageroot + 1 < 32) {
            i1 = i + (j << 6);
            c_x1 = -(u_bar[i1 + ((pageroot + 1) << 12)] - u_bar[i1 + (pageroot <<
                      12)]) / 0.03125;

            /*                  elseif l == 1 */
            /*                      a_star_u = -(u_bar(i,j,l)-u0(i,j))/ht; */
          } else {
            c_x1 = 32.0 * u_bar[(i + (j << 6)) + 126976];
          }

          /*  note F should include final cost at time T */
          /* now g = 1, G = m, linear in m. */
          f12_tmp = (i + (j << 6)) + (pageroot << 12);
          temp_m = m[f12_tmp] + 0.5 * (c_x1 - (double)obs[f12_tmp]);
          pp2_idx_2 = w1[f12_tmp] + 0.5 * matrix_m_w[f12_tmp];
          c_x1 = w2[f12_tmp] + 0.5 * B_star2[f12_tmp];
          c1_x1 = w3[f12_tmp] + 0.5 * B_star3[f12_tmp];
          pp2_idx_3 = w4[f12_tmp] + 0.5 * B_star4[f12_tmp];
          if (pageroot + 1 < 32) {
            /* solve for cubic root */
            kernel_sigma2 = pp2_idx_2 * (double)(pp2_idx_2 >= 0.0);
            kernel_sigma1 = c_x1 * (double)(c_x1 <= 0.0);
            pp2_idx_2 = c1_x1 * (double)(c1_x1 >= 0.0);
            pp2_idx_3 *= (double)(pp2_idx_3 <= 0.0);
            c_x1 = 0.0;
            for (k = 0; k < 10; k++) {
              c_x1 += a_bar[k + 10 * pageroot] * f[(i + (j << 6)) + (k << 12)];
            }

            c_x1 = cubic_poly_solve((0.5 * c_x1 - temp_m) - 0.5, -0.25 *
              (((kernel_sigma2 * kernel_sigma2 + kernel_sigma1 * kernel_sigma1)
                + pp2_idx_2 * pp2_idx_2) + pp2_idx_3 * pp2_idx_3));
            c_x1 -= 0.5;
            if (c_x1 <= 0.0) {
              m[f12_tmp] = 0.0;
              w1[f12_tmp] = 0.0;
              w2[f12_tmp] = 0.0;
              w3[f12_tmp] = 0.0;
              w4[f12_tmp] = 0.0;
            } else {
              c1_x1 = c_x1 / (c_x1 + 0.5);
              m[f12_tmp] = c_x1;
              w1[f12_tmp] = c1_x1 * kernel_sigma2;
              w2[f12_tmp] = c1_x1 * kernel_sigma1;
              w3[f12_tmp] = c1_x1 * pp2_idx_2;
              w4[f12_tmp] = c1_x1 * pp2_idx_3;
            }
          } else {
            /* solve for cubic root */
            kernel_sigma2 = pp2_idx_2 * (double)(pp2_idx_2 >= 0.0);
            kernel_sigma1 = c_x1 * (double)(c_x1 <= 0.0);
            pp2_idx_2 = c1_x1 * (double)(c1_x1 >= 0.0);
            pp2_idx_3 *= (double)(pp2_idx_3 <= 0.0);
            c_x1 = 0.0;
            for (k = 0; k < 10; k++) {
              c_x1 += a_bar[k + 310] * f[(i + (j << 6)) + (k << 12)];
            }

            c_x1 = cubic_poly_solve(((0.5 * c_x1 + 0.5 * (f0[i + (j << 6)] /
              0.03125)) - temp_m) - 0.5, -0.25 * (((kernel_sigma2 *
              kernel_sigma2 + kernel_sigma1 * kernel_sigma1) + pp2_idx_2 *
              pp2_idx_2) + pp2_idx_3 * pp2_idx_3));
            c_x1 -= 0.5;
            if (c_x1 <= 0.0) {
              i1 = (i + (j << 6)) + 126976;
              m[i1] = 0.0;
              w1[i1] = 0.0;
              w2[i1] = 0.0;
              w3[i1] = 0.0;
              w4[i1] = 0.0;
            } else {
              c1_x1 = c_x1 / (c_x1 + 0.5);
              i1 = (i + (j << 6)) + 126976;
              m[i1] = c_x1;
              w1[i1] = c1_x1 * kernel_sigma2;
              w2[i1] = c1_x1 * kernel_sigma1;
              w3[i1] = c1_x1 * pp2_idx_2;
              w4[i1] = c1_x1 * pp2_idx_3;
            }
          }
        }
      }
    }
  }

  toc();
}

/* End of code generation (run_mfg_moving_obs.c) */
