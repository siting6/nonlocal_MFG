/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * ThomasAlgorithm_complex.h
 *
 * Code generation for function 'ThomasAlgorithm_complex'
 *
 */

#ifndef THOMASALGORITHM_COMPLEX_H
#define THOMASALGORITHM_COMPLEX_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "omp.h"
#include "run_mfg_moving_obs_types.h"

/* Function Declarations */
extern void ThomasAlgorithm_complex(const double b[32], const creal_T f[32],
  creal_T s[32]);

#endif

/* End of code generation (ThomasAlgorithm_complex.h) */
